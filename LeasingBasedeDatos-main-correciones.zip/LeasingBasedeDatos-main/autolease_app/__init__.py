"""AutoLease Peru desktop application."""
